/*
 * MSVC-specific configuration for precursors.
 *
 * This file is the analogue of the config.h file created by the configure
 * script for Unix and Unix-like platforms. Since the configure script is not
 * invoked by MSVC users, the MSVC build instead gleans project configuration
 * information from this file, which must be maintained manually.
 */

/* Insert MSVC-specific configuration information here. */

