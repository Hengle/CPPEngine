

//-----------------------------------------------------------------------------
// File: Path.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _PATH_H
#define _PATH_H

#include "DXErrors.h"

typedef struct _PATHPOINT
{
    FLOAT fTime;
    D3DXVECTOR3 vPosition;
    D3DXVECTOR3 vPositionD2;
    D3DXQUATERNION qOrientation;
    D3DXQUATERNION qOrientationD2;
} PATHPOINT;

class CPath
{
    PATHPOINT *m_pPoints;
    INT m_dwCount;
    FLOAT m_fPathTime;

    VOID CalcOrientationD2(D3DXQUATERNION &qOrientationD2, D3DXQUATERNION &q0,
        D3DXQUATERNION &q1, D3DXQUATERNION &q2);
    VOID InitInterpolation();
    VOID InterpolatePostiontion();
    VOID InterpolateOrientation();

public:
    CPath();
    ~CPath();

    HRESULT Load(TCHAR *strPathName);
    VOID Play(FLOAT fTime, D3DXVECTOR3 &vPosition, D3DXQUATERNION &qOrientation);
    FLOAT GetPathTime();
};

#endif

