

//-----------------------------------------------------------------------------
// File: Material.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _MATERIAL_H
#define _MATERIAL_H

#include "DXErrors.h"
#include "Texture.h"
#include "TManager.h"

class CMaterial
{
    D3DMATERIAL9 m_Mtrl;
    DWORD m_dwTexIndx; // -1 if not loaded

public:
    CMaterial();
    ~CMaterial();
    HRESULT LoadMaterial(FILE *fp);
    HRESULT LoadMaterial(D3DMATERIAL9 &mtrl, TCHAR *tname, BOOL mipmap, BOOL alpha);
    VOID SetMaterial();
    VOID DeleteTexture();
};

#endif

