

//-----------------------------------------------------------------------------
// File: LitVertex.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _LITVERTEX_H
#define _LITVERTEX_H

#include "DXErrors.h"

// Prelit vertex with one set of texture coordinates
#define D3DFVF_LVERTEX1 (D3DFVF_XYZ | D3DFVF_DIFFUSE |D3DFVF_TEX1)

typedef struct _LITVERTEX
{
    float x, y, z;
    D3DCOLOR color;
    float tu, tv;
#if (defined __cplusplus) && (defined D3D_OVERLOADS)
    _LITVERTEX() { }
    _LITVERTEX(const D3DXVECTOR3& v, D3DCOLOR _color, float _tu, float _tv)
    {
        x = v.x; y = v.y; z = v.z;
        color = _color; tu = _tu; tv = _tv;
    }
#endif
} LITVERTEX, *LPLITVERTEX;

//#define D3DFVF_LVERTEX1 ZZZ
typedef struct _D3DVERTEX {
  union {
    float x;         /* Homogeneous coordinates */
    float dvX;
  };
  union {
    float y;
    float dvY;
  };
  union {
    float z;
    float dvZ;
  };
  union {
    float nx;        /* Normal */
    float dvNX;
  };
  union {
    float ny;
    float dvNY;
  };
  union {
    float nz;
    float dvNZ;
  };
  union {
    float tu;        /* Texture coordinates */
    float dvTU;
  };
  union {
    float tv;
    float dvTV;
  };
#if(DIRECT3D_VERSION >= 0x0500)
#if (defined __cplusplus) && (defined D3D_OVERLOADS)
  _D3DVERTEX() { }
  _D3DVERTEX(const /*D3DXVECTOR3*/D3DXVECTOR3& v, const /*D3DXVECTOR3*/D3DXVECTOR3& n, float _tu, float _tv)
    {
      x = v.x; y = v.y; z = v.z;
      nx = n.x; ny = n.y; nz = n.z;
      tu = _tu; tv = _tv;
    }
#endif
#endif /* DIRECT3D_VERSION >= 0x0500 */
  enum _FVF
    {
        FVF = D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1
    };
} D3DVERTEX, *LPD3DVERTEX;
#define D3DFVF_VERTEX D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1
#endif

