

//-----------------------------------------------------------------------------
// File: Helper.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _HELPER_H
#define _HELPER_H

#include "DXErrors.h"

#define PI 3.1415926535897932384626433832795f

#define SAFE_DELETE(p)  { if(p) { delete p; (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p)  { if(p) { delete []p; (p)=NULL; } }
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

typedef struct _CLIPVOLUME
{
    D3DXPLANE pLeft, pRight;
    D3DXPLANE pTop, pBottom;
    D3DXPLANE pNear, pFar;
} CLIPVOLUME;

void ComputeViewMatrix(D3DXMATRIX *matView, D3DXVECTOR3 *vEye, D3DXVECTOR3 *vDir, D3DXVECTOR3 *vUp);

#endif

