

//-----------------------------------------------------------------------------
// File: Skydome.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "Skydome.h"
#include "MManager.h"
#include "DXErrors.h"

CSkyDome::CSkyDome() : CModel()
{
    m_mSkyID = -1;
    m_mGroundID = -1;
    m_pSkyVert = NULL;
    m_pSkyVB = NULL;
    m_pGroundVert = NULL;
    m_pGroundVB = NULL;
}

CSkyDome::~CSkyDome()
{
    SAFE_DELETE(m_pSkyVert);
    SAFE_DELETE(m_pGroundVert);
    Destroy();
}

HRESULT CSkyDome::Load()
{
    FILE *fp;
    CHAR type[9];
    DWORD version;

    // Load sky model
    SAFE_DELETE(m_pSkyVert);

    if ((fp = fopen("sky.dat","rb")) == NULL)
        return E_FAIL;

    fread(type, sizeof(CHAR), 8, fp);
    fread(&version, sizeof(DWORD), 1, fp);
    type[8] = '\0';
    if (strcmp(type, "SKY_FILE"))
    {
        fclose(fp);
        return E_FAIL;
    }

    fread(&m_dwSkyNumVert, sizeof(DWORD), 1, fp);
    m_pSkyVert = new LITVERTEX[m_dwSkyNumVert];
    fread(m_pSkyVert, sizeof(LITVERTEX), m_dwSkyNumVert, fp);

    fclose(fp);

    // Load lower ground model
    SAFE_DELETE(m_pGroundVert);

    if ((fp = fopen("ground.dat","rb")) == NULL)
        return E_FAIL;

    fread(type, sizeof(CHAR), 8, fp);
    fread(&version, sizeof(DWORD), 1, fp);
    type[8] = '\0';
    if (strcmp(type, "GND_FILE"))
    {
        fclose(fp);
        return E_FAIL;
    }

    fread(&m_dwGroundNumVert, sizeof(DWORD), 1, fp);
    m_pGroundVert = new LITVERTEX[m_dwGroundNumVert];
    fread(m_pGroundVert, sizeof(LITVERTEX), m_dwGroundNumVert, fp);

    fclose(fp);

    D3DMATERIAL9 m;
    ZeroMemory(&m, sizeof(D3DMATERIAL9));
    m.Diffuse.r = m.Ambient.r = 1.0f;
    m.Diffuse.g = m.Ambient.g = 1.0f;
    m.Diffuse.b = m.Ambient.b = 1.0f;
    m.Diffuse.a = m.Ambient.a = 1.0f;

    CMaterial *mtrl;
    mtrl = new CMaterial();
    mtrl->LoadMaterial(m, _T("Sky1"), FALSE, FALSE);
    m_mSkyID = GameState::m_MMan->AddMaterial(mtrl);

    mtrl = new CMaterial();
    mtrl->LoadMaterial(m, _T("Ground"), TRUE, FALSE);
    m_mGroundID = GameState::m_MMan->AddMaterial(mtrl);

    return S_OK;
}

HRESULT CSkyDome::Init()
{
    LPLITVERTEX pvbVertices;

    if ((m_pSkyVert == NULL) || (m_pGroundVert == NULL))
        return E_FAIL;

    // Create and fill sky VB
    if (m_pSkyVB == NULL)
    {
        GameState::m_pd3dDevice->CreateVertexBuffer(m_dwSkyNumVert*sizeof(LITVERTEX),
                               D3DUSAGE_WRITEONLY,
                               D3DFVF_LVERTEX1,
                               /*D3DPOOL_MANAGED*/D3DPOOL_DEFAULT,
                               &m_pSkyVB,
                               NULL );
    }

    if (SUCCEEDED(m_pSkyVB->Lock( 0, 4*sizeof(LITVERTEX), (void**)&pvbVertices, 0 )))
    {
        DWORD i;
        for(i = 0; i < m_dwSkyNumVert; i++)
    {
            pvbVertices[i] = m_pSkyVert[i];
    }
        m_pSkyVB->Unlock();
    }

    // Create and fill lower ground VB
    if (m_pGroundVB == NULL)
    {
        GameState::m_pd3dDevice->CreateVertexBuffer(m_dwGroundNumVert*sizeof(LITVERTEX),
                               D3DUSAGE_WRITEONLY,
                               D3DFVF_LVERTEX1,
                               /*D3DPOOL_MANAGED*/D3DPOOL_DEFAULT,
                               &m_pGroundVB,
                               NULL );
    }

    if (SUCCEEDED(m_pGroundVB->Lock( 0, m_dwGroundNumVert*sizeof(LITVERTEX), (void**)&pvbVertices, 0 )))
    {
        DWORD i;
        for(i = 0; i < m_dwGroundNumVert; i++)
    {
            pvbVertices[i] = m_pGroundVert[i];
    }
        m_pGroundVB->Unlock();
    }

    return S_OK;
}

VOID CSkyDome::Destroy()
{
    SAFE_RELEASE(m_pSkyVB);
    SAFE_RELEASE(m_pGroundVB);
}

HRESULT CSkyDome::Render()
{
    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, FALSE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

    CMaterial *mtrl;

    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_LINEAR);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_NONE);

    FLOAT start = 50000.0f;
    FLOAT end = 400000.0f;
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGCOLOR, 0x00ADB4C7);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGSTART, *(DWORD*)(&start));
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGEND, *(DWORD*)(&end));

    mtrl = GameState::m_MMan->GetMaterial(m_mGroundID);
    if (mtrl != NULL)
        mtrl->SetMaterial();
    //GameState::m_pd3dDevice->DrawPrimitiveVB(D3DPT_TRIANGLELIST, m_pGroundVB, 0, m_dwGroundNumVert, 0L);
    GameState::m_pd3dDevice->SetFVF(D3DFVF_LVERTEX1);
    GameState::m_pd3dDevice->SetStreamSource( 0, m_pGroundVB, 0, sizeof(LITVERTEX) );
    GameState::m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST,  0, m_dwGroundNumVert/3 );

    mtrl = GameState::m_MMan->GetMaterial(m_mSkyID);
    if (mtrl != NULL)
        mtrl->SetMaterial();
    //GameState::m_pd3dDevice->DrawPrimitiveVB(D3DPT_TRIANGLELIST, m_pSkyVB, 0, m_dwSkyNumVert, 0L);
    GameState::m_pd3dDevice->SetStreamSource( 0, m_pSkyVB, 0, sizeof(LITVERTEX) );
    GameState::m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLELIST,  0, m_dwSkyNumVert/3 );

    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);

    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);

    return S_OK;
}

DWORD CSkyDome::CountPolys()
{
    return (m_dwSkyNumVert + m_dwGroundNumVert)/ 3;
}

