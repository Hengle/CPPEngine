//-----------------------------------------------------------------------------
// File: TriangleList.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include <math.h>
#include "Helper.h"
#include "TriangleList.h"
#include "DXErrors.h"


CTriangleList::CTriangleList()
{
    m_pIndicesIB=0;
    m_pIndices = NULL;
    m_dwMaterialID = -1;
}

CTriangleList::CTriangleList(FILE *fp)
{
    m_pIndicesIB=0;
    m_pIndices = NULL;
    m_dwMaterialID = -1;

    Load(fp);
}

CTriangleList::~CTriangleList()
{
    DeleteArrays();
}

VOID CTriangleList::DeleteArrays()
{
    if(m_pIndicesIB)m_pIndicesIB->Release();
    if (m_pIndices != NULL)
    {
        delete []m_pIndices;
        m_pIndices = NULL;
    }
}

HRESULT CTriangleList::Load(FILE *fp)
{
    DeleteArrays();

    fread(&m_dwMaterialID, sizeof(DWORD), 1, fp);
    fread(&m_dwIndNum, sizeof(DWORD), 1, fp);
    fread(&m_dwVBID, sizeof(DWORD), 1, fp);

    m_pIndices = new WORD[m_dwIndNum];
    fread(m_pIndices, sizeof(WORD), m_dwIndNum, fp);

  if( FAILED(GameState::m_pd3dDevice->CreateIndexBuffer(m_dwIndNum*sizeof(DWORD), D3DUSAGE_WRITEONLY, D3DFMT_INDEX32, /*D3DPOOL_MANAGED*/D3DPOOL_DEFAULT, &m_pIndicesIB, NULL))){return -1;};
  DWORD* pIndices2=0;
  if( FAILED( m_pIndicesIB->Lock(0,0,(void **) &pIndices2,0))){return -1;};
  for(unsigned int ii=0;ii< m_dwIndNum;ii++)
{
           ((DWORD*)pIndices2)[ii]=((WORD*)m_pIndices)[ii];
           #ifdef VERTEXCACHE
           ((DWORD*)m_pdwIndices)[ii]=((WORD*)m_pIndices)[ii];
           #endif
}
  if( FAILED(m_pIndicesIB->Unlock())){return -1;};

      delete []m_pIndices;//???
      m_pIndices = NULL;

    return S_OK;
}

HRESULT CTriangleList::Render( CVertexStore *pVS)
{
    DWORD size;
    LPDIRECT3DVERTEXBUFFER9 pVB;

    pVB = pVS->GetVertexBuffer(m_dwVBID, &size);
    //GameState::m_pd3dDevice->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
    //  pVB, 0, size, m_pIndices, m_dwIndNum, 0);
    GameState::m_pd3dDevice->SetStreamSource( 0, pVB, 0,sizeof(LITVERTEX));
    GameState::m_pd3dDevice->SetIndices(m_pIndicesIB);
    GameState::m_pd3dDevice->SetFVF( D3DFVF_LVERTEX1 );
    GameState::m_pd3dDevice->DrawIndexedPrimitive( D3DPT_TRIANGLELIST, 0,0,size, 0, m_dwIndNum/3);
    GameState::m_pd3dDevice->SetFVF(0);

    return S_OK;
}
