

//-----------------------------------------------------------------------------
// File: Octree.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _OCTREE_H
#define _OCTREE_H

#include "DXErrors.h"
#include "TriangleList.h"
#include "RenderQueue.h"
#include "Helper.h"

class COctreeNode
{
    D3DXVECTOR3 m_vCenter;
    D3DXVECTOR3 m_vCorners[8];
    // Node dimentions
    FLOAT m_fWidth;
    FLOAT m_fHeight;
    FLOAT m_fDepth;
    // Number of strips
    DWORD m_dwListCount;
    // Triangle lists
    CTriangleList *m_pTriangleLists;
    // Children of this node
    COctreeNode *m_pKids[8];

    VOID ReadTree(FILE *fp);

public:
    COctreeNode(FILE *fp);
    ~COctreeNode();
    VOID Cull(CRenderQueue *pRQ, CLIPVOLUME& cv, D3DXVECTOR3& pos);
};

#endif

