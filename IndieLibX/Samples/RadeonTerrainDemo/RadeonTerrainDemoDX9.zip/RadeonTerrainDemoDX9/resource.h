

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TerrainDemo.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_ABOUT                       143
#define IDD_CHANGEDEVICE                144
#define IDC_DEVICE_COMBO                1000
#define IDC_MODE_COMBO                  1001
#define IDC_WINDOWED_CHECKBOX           1012
#define IDC_STEREO_CHECKBOX             1013
#define IDC_FULLSCREEN_TEXT             1014
#define IDM_ABOUT                       40001
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_TOGGLESTART                 40004
#define IDM_SINGLESTEP                  40005
#define IDM_EXIT                        40006
#define IDM_CHANGEDXT                   40018

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         40019
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif

