

//-----------------------------------------------------------------------------
// File: SplashScreen.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _SPLASHSCREEN_H
#define _SPLASHSCREEN_H

#include "DXErrors.h"
#include "Demo.h"

class CSplashScreen : public CDemo
{
private:
    BOOL m_bFinished;
    D3DVERTEX m_vMesh[4];
    LPDIRECT3DVERTEXBUFFER9 m_vMeshVB;
    DWORD m_dwTexIndx; // -1 if not loaded

    VOID DeleteTexture();

public:
    CSplashScreen();
    ~CSplashScreen();
    HRESULT Load();
    HRESULT Init();
    VOID Destroy();
    HRESULT Render(FLOAT fTime );
};

#endif

