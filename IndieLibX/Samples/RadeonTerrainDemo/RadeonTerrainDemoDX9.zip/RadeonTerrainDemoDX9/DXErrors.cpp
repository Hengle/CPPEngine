

//-----------------------------------------------------------------------------
// File: DXErrors.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "DXErrors.h"

#ifdef _MSC_VER
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9d.lib")
#pragma comment(lib, "wbemuuid.lib")
#pragma comment(lib, "ole32.lib")
#pragma comment(lib, "oleaut32.lib")
#endif
#define AUTODEPTHSTENCILFORMAT D3DFMT_D16
#pragma comment(lib, "d3d9.lib")
#ifdef _DEBUG
#pragma comment(lib, "d3dx9d.lib")
#else
#pragma comment(lib, "d3dx9.lib")
#endif
#ifdef _DEBUG
#if (D3DX_SDK_VERSION >= 42)
#pragma comment (lib,"DxErr.lib")
#else
#pragma comment (lib,"Dxerr9.lib")
#endif
#endif

D3DCAPS9 GameState::m_caps;
LPDIRECT3D9 GameState::m_pD3D=NULL;
LPDIRECT3DDEVICE9 GameState::m_pd3dDevice=NULL;
CMaterialManager* GameState::m_MMan=NULL;
CTextureManager* GameState::m_TMan=NULL;
CViewer* GameState::m_Viewer=NULL;
CTerrainApp* GameState::m_App=NULL;

VOID _DbgOut(TCHAR* strFile, DWORD dwLine, HRESULT hr, TCHAR *strMsg)
{
    TCHAR buffer[256];

    wsprintf(buffer, _T("%s(%ld): "), strFile, dwLine);
    OutputDebugString(buffer);
    OutputDebugString(strMsg);
    if (hr)
    {
        wsprintf(buffer, _T("(hr=%08lx)\n"), hr);
        OutputDebugString(buffer);
    }
    OutputDebugString(_T("\n"));
}

VOID _ErrorOut(TCHAR *strFile, DWORD dwLine, HRESULT hr)
{

    TCHAR strErr[100];

    //D3DXGetErrorString(hr, 100, strErr);
    sprintf(strErr,"%s\n%s\n",DXGetErrorString(hr),DXGetErrorDescription(hr));
    _DbgOut(strFile, dwLine, hr, strErr);

}

