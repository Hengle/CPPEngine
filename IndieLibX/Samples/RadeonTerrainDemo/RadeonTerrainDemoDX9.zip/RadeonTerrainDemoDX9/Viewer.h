//-----------------------------------------------------------------------------
// File: Viewer.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _VIEWER_H
#define _VIEWER_H

#include "DXErrors.h"
#include "Helper.h"

// Frustum parameters
const FLOAT NEAR_CLIP = 150.0f;
const FLOAT FAR_CLIP = 250000.0f;
const FLOAT FOV = PI / 4.0f;

class CViewer
{
    // Viewer position and orientation
    D3DXVECTOR3 m_vUp;
    D3DXVECTOR3 m_vDir;
    D3DXVECTOR3 m_vPos;
    D3DXVECTOR3 m_vCross;

    D3DXMATRIX m_matView;
    D3DXMATRIX m_matProj;
    D3DXMATRIX m_matRot;
    FLOAT m_fAspect;

    VOID CalculateTransform();

public:
    CViewer();
    VOID SetAspect(FLOAT aspect);
    VOID UpdateViewer(
        D3DXVECTOR3 &pos, D3DXQUATERNION &quat);
    D3DXVECTOR3& GetPos();

    VOID ComputeClipVolume(CLIPVOLUME& cv);
};

#endif