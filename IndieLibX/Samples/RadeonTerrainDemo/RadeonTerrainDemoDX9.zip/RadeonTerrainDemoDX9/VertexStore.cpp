//-----------------------------------------------------------------------------
// File: VertexStore.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "VertexStore.h"
#include "DXErrors.h"

CVertexStore::CVertexStore(FILE *fp)
{
    fread(&m_dwVBCount, sizeof(DWORD), 1, fp);

    m_pVB = new VB[m_dwVBCount];
    for(DWORD i = 0; i < m_dwVBCount; i++)
    {
        fread(&m_pVB[i].dwSize, sizeof(DWORD), 1, fp);
        m_pVB[i].pVertices = new LITVERTEX[m_pVB[i].dwSize];
        fread(m_pVB[i].pVertices, sizeof(LITVERTEX), m_pVB[i].dwSize, fp);
        m_pVB[i].pVB = NULL;
    }
}

CVertexStore::~CVertexStore()
{
    for(DWORD i = 0; i < m_dwVBCount; i++)
    {
        SAFE_DELETE_ARRAY(m_pVB[i].pVertices);
    }
    SAFE_DELETE_ARRAY(m_pVB);
}

HRESULT CVertexStore::Init()
{
    for(DWORD i = 0; i < m_dwVBCount; i++)
    {
        if (m_pVB[i].pVB == NULL)
        {
            SAFE_RELEASE(m_pVB[i].pVB);

            GameState::m_pd3dDevice->CreateVertexBuffer(m_pVB[i].dwSize*sizeof(LITVERTEX),
                               D3DUSAGE_WRITEONLY,
                               D3DFVF_LVERTEX1,
                               /*D3DPOOL_MANAGED*/D3DPOOL_DEFAULT,
                               &m_pVB[i].pVB,
                               NULL );
        }

        LPLITVERTEX pvbVertices;
        if (SUCCEEDED(m_pVB[i].pVB->Lock( 0, m_pVB[i].dwSize*sizeof(LITVERTEX), (void**)&pvbVertices, 0 )))
        {
            memcpy(pvbVertices, m_pVB[i].pVertices, m_pVB[i].dwSize * sizeof(LITVERTEX));
            m_pVB[i].pVB->Unlock();
        }
        else
            return E_FAIL;
    }

    return S_OK;
}

VOID CVertexStore::Destroy()
{
    for(DWORD i = 0; i < m_dwVBCount; i++)
    {
        SAFE_RELEASE(m_pVB[i].pVB);
    }
}

LPDIRECT3DVERTEXBUFFER9 CVertexStore::GetVertexBuffer(DWORD index, DWORD *size)
{
    if (index < m_dwVBCount)
    {
        *size = m_pVB[index].dwSize;
        return m_pVB[index].pVB;
    }
    else
        return NULL;
}
