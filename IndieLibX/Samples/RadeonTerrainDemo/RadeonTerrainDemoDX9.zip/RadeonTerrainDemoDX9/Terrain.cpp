

//-----------------------------------------------------------------------------
// File: Terrain.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "Terrain.h"
#include "Viewer.h"
#include "DXErrors.h"

#define SFC_SIGN "SFC_FILE"

CTerrain::CTerrain() : CModel()
{
    m_pOT = NULL;
    m_pVS = NULL;
    m_pRQ = new CRenderQueue();
//  m_bDetailTexture = FALSE;
}

CTerrain::~CTerrain()
{
    SAFE_DELETE(m_pOT);
    SAFE_DELETE(m_pVS);
    SAFE_DELETE(m_pRQ);
}

HRESULT CTerrain::Load()
{
    FILE *fp;
    CHAR signature[9];
    DWORD version;

    if ((fp = fopen("../RadeonTerrainDemoDX7/terrain.dat", "rb")) == NULL)
        return E_FAIL;

    fread(signature, sizeof(CHAR), 8, fp);
    signature[8]='\0';
    fread(&version, sizeof(DWORD), 1, fp);

    if (strcmp(signature, SFC_SIGN))
    {
        fclose(fp);
        return E_FAIL;
    }

    m_pVS = new CVertexStore(fp);
    m_pOT = new COctreeNode(fp);

    fclose(fp);

    return S_OK;
}

HRESULT CTerrain::Init()
{
    return m_pVS->Init();
}

VOID CTerrain::Destroy()
{
    m_pVS->Destroy();
}

HRESULT CTerrain::Render()
{
    if (m_pOT != NULL)
    {
        CLIPVOLUME cv;
        D3DXVECTOR3 pos = GameState::m_Viewer->GetPos();

        GameState::m_Viewer->ComputeClipVolume(cv);
        m_pRQ->ClearQueue();
        m_pOT->Cull(m_pRQ, cv, pos);

        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, TRUE);
        GameState::m_pd3dDevice->SetRenderState(D3DRS_RANGEFOGENABLE, TRUE);
        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGVERTEXMODE, D3DFOG_LINEAR);
        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_NONE);

        FLOAT start = 50000.0f;
        FLOAT end = 400000.0f;
        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGCOLOR, 0x00ADB4C7);
        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGSTART, *(DWORD*)(&start));
        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGEND, *(DWORD*)(&end));

        GameState::m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_CW);
        GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

        m_pRQ->Render(m_pVS);

        GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);
    }
    return S_OK;
}

DWORD CTerrain::CountPolys()
{
    return m_pRQ->CountPolys();
}

