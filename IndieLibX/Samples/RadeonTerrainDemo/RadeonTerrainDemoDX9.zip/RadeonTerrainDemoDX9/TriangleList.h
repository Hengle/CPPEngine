//-----------------------------------------------------------------------------
// File: TriangleList.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _TRIANGLELIST_H
#define _TRIANGLELIST_H

#include "DXErrors.h"
#include "LitVertex.h"
#include "VertexStore.h"

class CTriangleList
{
    VOID DeleteArrays();

public:
    DWORD m_dwMaterialID;
    LPDIRECT3DINDEXBUFFER9 m_pIndicesIB;
    WORD *m_pIndices;
    DWORD m_dwIndNum;
    DWORD m_dwVBID;

    CTriangleList();
    CTriangleList(FILE *fp);
    ~CTriangleList();
    HRESULT Load(FILE *fp);
    HRESULT Render( CVertexStore *pVS);
};

#endif
