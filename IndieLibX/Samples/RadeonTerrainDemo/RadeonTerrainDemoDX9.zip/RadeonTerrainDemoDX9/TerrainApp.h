

//-----------------------------------------------------------------------------
// File: TerrainApp.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _TERRAINAPP_H
#define _TERRAINAPP_H

#include "DXErrors.h"
#include "FlyDemo.h"
#include "SplashScreen.h"

class CTerrainApp
{
protected:
    LPCTSTR m_strAppName;
    HWND m_hWnd;

    // D3D interfaces
    //ID3DXContext *m_pD3DX;
    //LPDIRECTDRAW7 m_pDD;
    //LPDIRECT3D9 m_pD3D;
    LPD3DXFONT   m_pd3dxFont;

    // Window size
    DWORD m_dwFSWidth;
    DWORD m_dwFSHeight;
    BOOL m_bActive;

    // Demo renderers
    CFlyDemo *m_pFlyDemo;
    CSplashScreen *m_pSplash;

    // Time keeping stuff
    DWORD m_dwStartTime;
    DWORD m_dwTime;

    // Execution mode flags
    BOOL m_bInitialized;
    BOOL m_bShowingDemo;
    BOOL m_bNoTnL;
    BOOL m_bWindowed;

    // Performance stats
    DWORD m_dwFPS;
    DWORD m_dwPPS;
    DWORD m_dwLoopFrames;
    DWORD m_dwLoopCount;
    DWORD m_dwLastPerfTime;
    CHAR m_strStats[128];

    HRESULT InitApplication(HINSTANCE hInstance);
    HRESULT InitInstance(HINSTANCE hInstance, INT nCmdShow);
    HRESULT ParseCommandLine(LPSTR lpszCmdLine);

    HRESULT InitializeD3DX();
    HRESULT UnInitializeD3DX();
    HRESULT Startup();
    HRESULT InitRenderer();
    HRESULT MessageLoop();
    VOID SetActive(BOOL bActive);

    HRESULT RestoreContext();

    VOID StartTime();
    VOID UpdateTime();
    HRESULT DrawFrame();
    HRESULT Draw();

public:
    CTerrainApp();
    ~CTerrainApp();

    HRESULT Run(HINSTANCE hInstance, HINSTANCE hPrevInstance,
        LPSTR lpszCmdLine, INT nCmdShow);
    LRESULT WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif

