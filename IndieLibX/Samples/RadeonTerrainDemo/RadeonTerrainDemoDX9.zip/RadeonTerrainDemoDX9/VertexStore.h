//-----------------------------------------------------------------------------
// File: VertexStore.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _VERTEXSTORE_H
#define _VERTEXSTORE_H

#include "DXErrors.h"
#include "LitVertex.h"
#include "Helper.h"

typedef struct tagVB
{
    DWORD dwSize;
    LITVERTEX *pVertices;
    LPDIRECT3DVERTEXBUFFER9 pVB;
} VB;

class CVertexStore
{
    VB *m_pVB;
    DWORD m_dwVBCount;

public:
    CVertexStore(FILE *fp);
    ~CVertexStore();

    HRESULT Init();
    VOID Destroy();
    LPDIRECT3DVERTEXBUFFER9 GetVertexBuffer(DWORD index, DWORD *size);
};

#endif
