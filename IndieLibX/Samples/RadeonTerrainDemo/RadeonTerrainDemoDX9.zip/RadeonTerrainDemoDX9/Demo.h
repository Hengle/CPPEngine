

//-----------------------------------------------------------------------------
// File: Demo.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _DEMO_H
#define _DEMO_H

#include "DXErrors.h"

class CDemo
{
public:
    BOOL m_bLoaded;
    BOOL m_bInitialized;
    BOOL m_bWireframe;

    CDemo() { m_bWireframe = FALSE; };
    virtual HRESULT Load() { return S_OK; };
    virtual HRESULT Init() { return S_OK; };
    virtual VOID Destroy() {};
    virtual HRESULT Render(FLOAT fTime ) { return S_OK; };
    VOID ToggleWireframe() { m_bWireframe = !m_bWireframe; };
};

#endif

