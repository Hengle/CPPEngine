

//-----------------------------------------------------------------------------
// File: SplashScreen.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "SplashScreen.h"
#include "Texture.h"
#include "TManager.h"
#include "DXErrors.h"


CSplashScreen::CSplashScreen() : CDemo()
{
    m_dwTexIndx = -1;
    m_bLoaded = FALSE;
    m_bInitialized = FALSE;
    m_vMeshVB=0;
}

CSplashScreen::~CSplashScreen()
{
    DeleteTexture();
    if(m_vMeshVB)m_vMeshVB->Release();
}

HRESULT CSplashScreen::Load()
{
    HRESULT hr;

    D3DXVECTOR3 n = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
    m_vMesh[0] = D3DVERTEX(D3DXVECTOR3(-1.0f,-1.0f, 0.0f), n, 1.0f, 1.0f);
    m_vMesh[1] = D3DVERTEX(D3DXVECTOR3(-1.0f, 1.0f, 0.0f), n, 1.0f, 0.0f);
    m_vMesh[2] = D3DVERTEX(D3DXVECTOR3( 1.0f,-1.0f, 0.0f), n, 0.0f, 1.0f);
    m_vMesh[3] = D3DVERTEX(D3DXVECTOR3( 1.0f, 1.0f, 0.0f), n, 0.0f, 0.0f);

    //LOG_PRINT("GameState::m_pd3dDevice=%d\n",GameState::m_pd3dDevice);
    hr=GameState::m_pd3dDevice->CreateVertexBuffer( 4*sizeof(D3DVERTEX),D3DUSAGE_WRITEONLY,
                         D3DVERTEX::FVF,
                      /*D3DPOOL_MANAGED*/D3DPOOL_DEFAULT, &m_vMeshVB, NULL );
    //LOG_PRINT("hr=%d\n",hr);
    D3DVERTEX* pVertices0=0;
    m_vMeshVB->Lock( 0, 4*sizeof(D3DVERTEX), (void**)&pVertices0, 0 );
    memcpy( pVertices0, m_vMesh, 4*sizeof(D3DVERTEX) );
    m_vMeshVB->Unlock();

    CTexture *pTexture = new CTexture();
    hr = pTexture->Create(_T("splash"), FALSE, FALSE);
    if (FAILED(hr))
    {
        SAFE_DELETE(pTexture);
        return E_FAIL;
    }
    m_dwTexIndx = GameState::m_TMan->AddTexture(pTexture);
    m_bLoaded = TRUE;

    return S_OK;
}

HRESULT CSplashScreen::Init()
{
    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);//D3DTSS_ADDRESS, D3DTADDRESS_WRAP);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);//D3DTSS_ADDRESS, D3DTADDRESS_WRAP);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);//D3DTSS_ADDRESS, D3DTADDRESS_WRAP);

    GameState::m_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_DITHERENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_COLORVERTEX, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_SPECULARENABLE, FALSE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_LOCALVIEWER, FALSE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FOGENABLE, FALSE);

    D3DVIEWPORT9 vp;
    GameState::m_pd3dDevice->GetViewport(&vp);
    FLOAT fAspect = ((FLOAT)vp.Height) / vp.Width;

    // Load world transform
    D3DXMATRIX matWorld;
    D3DXMatrixIdentity(&matWorld);
    GameState::m_pd3dDevice->SetTransform(D3DTS_WORLD, &matWorld);

    // Setup projection
    D3DXMATRIX matProj;
    D3DXMatrixPerspectiveFovLH(&matProj, PI / 3.0f, fAspect, 0.1f, 100.0f);
    GameState::m_pd3dDevice->SetTransform(D3DTS_PROJECTION, &matProj);

    // Load view transform
    D3DXVECTOR3 vViewer(0.0f, 0.0f, 2.0f);
    D3DXVECTOR3 vDir(0.0f, 0.0f, -1.0f);
    D3DXVECTOR3 vUp(0.0f, 1.0f, 0.0f);
    D3DXMATRIX matView;
    ComputeViewMatrix(&matView, &vViewer, &vDir, &vUp);
    GameState::m_pd3dDevice->SetTransform(D3DTS_VIEW, &matView);

    m_bInitialized = TRUE;

    return S_OK;
}

VOID CSplashScreen::Destroy()
{
    m_bInitialized = FALSE;
}

HRESULT CSplashScreen::Render(FLOAT fTime )
{
    if ((m_bLoaded) && (m_bInitialized) && (m_dwTexIndx != -1))
    {
        CTexture *pTexture = GameState::m_TMan->GetTexture(m_dwTexIndx);
        if (pTexture != NULL)
        {
            GameState::m_pd3dDevice->SetTexture(0, pTexture->GetSurface());
            //GameState::m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, D3DFVF_VERTEX, m_vMesh, 4, 0);
            GameState::m_pd3dDevice->SetFVF(D3DVERTEX::FVF);
            GameState::m_pd3dDevice->SetStreamSource( 0, m_vMeshVB, 0, sizeof(D3DVERTEX) );
            GameState::m_pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2 );
        }
        else
            GameState::m_pd3dDevice->SetTexture(0, NULL);
    }

    return S_OK;
}

VOID CSplashScreen::DeleteTexture()
{
    if (m_dwTexIndx != -1)
    {
        GameState::m_TMan->DeleteTexture(m_dwTexIndx);
        m_dwTexIndx = -1;
    }
}

