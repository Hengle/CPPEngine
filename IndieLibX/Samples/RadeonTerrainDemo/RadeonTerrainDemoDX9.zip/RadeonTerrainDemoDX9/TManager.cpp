//-----------------------------------------------------------------------------
// File: TManager.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "TManager.h"
#include "DXErrors.h"

CTextureManager::CTextureManager()
{
    ZeroMemory(m_Textures, sizeof(m_Textures));
}

CTextureManager::~CTextureManager()
{
    for(DWORD i = 0; i < MAX_TEXTURES; i++)
    {
        DeleteTexture(i);
    }
}

CTexture *CTextureManager::GetTexture(DWORD n)
{
    if (n >= MAX_TEXTURES)
        return NULL;
    return m_Textures[n];
}

DWORD CTextureManager::AddTexture(CTexture *texture)
{
    for(DWORD i = 0; i < MAX_TEXTURES; i++)
    {
        if (m_Textures[i] == NULL)
        {
            m_Textures[i] = texture;
            return i;
        }
    }
    return -1;
}

HRESULT CTextureManager::DeleteTexture(DWORD n)
{
    if (n >= MAX_TEXTURES)
        return E_FAIL;
    SAFE_DELETE(m_Textures[n]);

    return S_OK;
}

HRESULT CTextureManager::RestoreAll()
{
    for(DWORD i = 0; i < MAX_TEXTURES; i++)
    {
        if (m_Textures[i] != NULL)
        {
            if (FAILED(m_Textures[i]->Restore()))
                return E_FAIL;
        }
    }

    return S_OK;
}

VOID CTextureManager::InvalidateAll()
{
    for(DWORD i = 0; i < MAX_TEXTURES; i++)
    {
        if (m_Textures[i] != NULL)
        {
            m_Textures[i]->Invalidate();
        }
    }
}
