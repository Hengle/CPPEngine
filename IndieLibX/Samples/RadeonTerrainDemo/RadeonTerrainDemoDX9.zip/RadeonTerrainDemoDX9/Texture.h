//-----------------------------------------------------------------------------
// File: Texture.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _TEXTURE_H
#define _TEXTURE_H

#include "DXErrors.h"
#include <tchar.h>

#define TEXTURE_PATH _T("texture\\")

class CTexture
{
    BOOL m_bHasAlpha;
    BOOL m_bMipMap;
    LPDIRECT3DTEXTURE9 m_pddsSurface;
    TCHAR m_strFileName[256];

public:
    CTexture();
    ~CTexture();
    HRESULT Create(TCHAR *strTexName, BOOL bMipMap, BOOL bAlpha);
    HRESULT Restore();
    VOID Invalidate();
    LPDIRECT3DTEXTURE9 GetSurface();
};

#endif
