

//-----------------------------------------------------------------------------
// File: Path.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "DXErrors.h"
#include "Helper.h"
#include "Path.h"

CPath::CPath()
{
    m_dwCount = 0;
    m_pPoints = NULL;
}

CPath::~CPath()
{
    SAFE_DELETE_ARRAY(m_pPoints);
}

HRESULT CPath::Load(TCHAR *strPathName)
{
    FILE *fp;

    SAFE_DELETE_ARRAY(m_pPoints);
    m_dwCount = 0;

    fp = _tfopen(strPathName,"r");
    if (fp == NULL)
        return E_FAIL;

    fscanf(fp, "%d", &m_dwCount);
    fscanf(fp, "%f", &m_fPathTime);

    m_pPoints = new PATHPOINT[m_dwCount + 1];

    for(INT i = 0; i < m_dwCount; i++)
    {
        fscanf(fp, "%f", &m_pPoints[i].fTime);
        // Load position
        fscanf(fp, "%f %f %f", &m_pPoints[i].vPosition.x,
            &m_pPoints[i].vPosition.y, &m_pPoints[i].vPosition.z);
        // Load orientation
        fscanf(fp, "%f %f %f %f", &m_pPoints[i].qOrientation.x,
            &m_pPoints[i].qOrientation.y, &m_pPoints[i].qOrientation.z, &m_pPoints[i].qOrientation.w);
    }
    fclose(fp);

    // Set ending point of the path
    m_pPoints[m_dwCount].fTime = m_fPathTime;
    m_pPoints[m_dwCount].qOrientationD2 = m_pPoints[0].qOrientationD2;
    m_pPoints[m_dwCount].qOrientation = m_pPoints[0].qOrientation;
    m_pPoints[m_dwCount].vPosition = m_pPoints[0].vPosition;
    m_pPoints[m_dwCount].vPositionD2 = m_pPoints[0].vPositionD2;

    InitInterpolation();

    return S_OK;
}

VOID CPath::CalcOrientationD2(D3DXQUATERNION &qOrientationD2, D3DXQUATERNION &q0,
                    D3DXQUATERNION &q1, D3DXQUATERNION &q2)
{
    D3DXQUATERNION q, qt1, qt2, qInv;

    D3DXQuaternionInverse(&qInv, &q1);
    //
    if (D3DXQuaternionDot(&q0, &q1) < 0.0f)
        q0 *= -1.0f;
    if (D3DXQuaternionDot(&q2, &q1) < 0.0f)
        q2 *= -1.0f;

    D3DXQuaternionLn(&qt1, D3DXQuaternionMultiply(&q, &qInv, &q0));
    D3DXQuaternionLn(&qt2, D3DXQuaternionMultiply(&q, &qInv, &q2));
    q = -(qt1 + qt2) / 4.0f;
    D3DXQuaternionMultiply(&qOrientationD2, &q1, D3DXQuaternionExp(&qt1, &q));
}

VOID CPath::InitInterpolation()
{
    INT i;
    D3DXVECTOR3 *vP;
    D3DXVECTOR3 *vD2;
    D3DXVECTOR3 *vIV;
    D3DXVECTOR3 v;
    FLOAT *fT;
    FLOAT dT, f1, fP;

    // Calculate second derivatives for path interpolation
    vP = new D3DXVECTOR3[m_dwCount + 11];
    vD2 = new D3DXVECTOR3[m_dwCount + 11];
    vIV = new D3DXVECTOR3[m_dwCount + 11];
    fT = new FLOAT[m_dwCount + 11];

    for(i = 0; i < 5; i++)
    {
        vP[i] = m_pPoints[m_dwCount - 5 + i].vPosition;
        fT[i] = m_pPoints[m_dwCount - 5 + i].fTime - m_fPathTime;
    }
    for(i = 0; i < m_dwCount; i++)
    {
        vP[i + 5] = m_pPoints[i].vPosition;
        fT[i + 5] = m_pPoints[i].fTime;
    }
    for(i = 0; i < 5; i++)
    {
        vP[m_dwCount + 5 + i] = m_pPoints[i].vPosition;
        fT[m_dwCount + 5 + i] = m_pPoints[i].fTime + m_fPathTime;
    }
    //
    vD2[0] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    vIV[0] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    for(i = 0; i < m_dwCount + 10; i++)
    {
        dT = (fT[i] - fT[i - 1]) / (fT[i + 1] - fT[i - 1]);

        fP = vD2[i - 1].x * dT + 2.0f;
        vD2[i].x = (dT - 1.0f) / fP;
        f1 = (vP[i + 1].x - vP[i].x) / (fT[i + 1] - fT[i]) -
            (vP[i].x - vP[i - 1].x) / (fT[i] - fT[i - 1]);
        vIV[i].x = (6.0f * f1 / (fT[i + 1] - fT[i - 1]) - dT * vIV[i - 1].x) / fP;

        fP = vD2[i - 1].y * dT + 2.0f;
        vD2[i].y = (dT - 1.0f) / fP;
        f1 = (vP[i + 1].y - vP[i].y) / (fT[i + 1] - fT[i]) -
            (vP[i].y - vP[i - 1].y) / (fT[i] - fT[i - 1]);
        vIV[i].y = (6.0f * f1 / (fT[i + 1] - fT[i - 1]) - dT * vIV[i - 1].y) / fP;

        fP = vD2[i - 1].z * dT + 2.0f;
        vD2[i].z = (dT - 1.0f) / fP;
        f1 = (vP[i + 1].z - vP[i].z) / (fT[i + 1] - fT[i]) -
            (vP[i].z - vP[i - 1].z) / (fT[i] - fT[i - 1]);
        vIV[i].z = (6.0f * f1 / (fT[i + 1] - fT[i - 1]) - dT * vIV[i - 1].z) / fP;
    }
    vD2[m_dwCount + 10] = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

    for(i = m_dwCount + 9; i >= 0; i--)
    {
        vD2[i].x = vD2[i].x * vD2[i + 1].x + vIV[i].x;
        vD2[i].y = vD2[i].y * vD2[i + 1].y + vIV[i].y;
        vD2[i].z = vD2[i].z * vD2[i + 1].z + vIV[i].z;
    }
    // Copy computed data
    for(i = 0; i < m_dwCount; i++)
    {
        m_pPoints[i].vPositionD2 = vD2[i + 5];
    }

    delete []vP;
    delete []vD2;
    delete []vIV;
    delete []fT;

    // Calculate second derivatives for orientation interpolation
    for(i = 0; i < m_dwCount; i++)
    {
        if (i == 0)
        {
            // Wrap around the path
            CalcOrientationD2(m_pPoints[i].qOrientationD2, m_pPoints[m_dwCount - 1].qOrientation,
                m_pPoints[i].qOrientation, m_pPoints[i + 1].qOrientation);
        }
        else
        {
            // Ensure shortest rotation
            if (D3DXQuaternionDot(&m_pPoints[i].qOrientation, &m_pPoints[i - 1].qOrientation) < 0.0f)
                m_pPoints[i].qOrientation *= -1.0f;
            CalcOrientationD2(m_pPoints[i].qOrientationD2, m_pPoints[i - 1].qOrientation,
                m_pPoints[i].qOrientation, m_pPoints[i + 1].qOrientation);
        }
    }
}

VOID CPath::Play(FLOAT fTime, D3DXVECTOR3 &vPosition, D3DXQUATERNION &qOrientation)
{
    fTime = fmodf(fTime, m_fPathTime);

    // Find path segment
    DWORD dwLBound, dwHBound;
    dwLBound = 0;
    dwHBound = m_dwCount;
    while (dwHBound - dwLBound > 1)
    {
        DWORD m = (dwHBound + dwLBound ) >> 1;
        if (m_pPoints[m].fTime > fTime)
            dwHBound = m;
        else
            dwLBound = m;
    }

    FLOAT dT = m_pPoints[dwHBound].fTime - m_pPoints[dwLBound].fTime;
    FLOAT fT = (fTime - m_pPoints[dwLBound].fTime) / dT;

    // Interpolate position
    FLOAT fTr = 1.0f - fT;
    vPosition = fTr * m_pPoints[dwLBound].vPosition +
        fT * m_pPoints[dwHBound].vPosition +
        ((fTr * fTr * fTr - fTr) * m_pPoints[dwLBound].vPositionD2 +
        (fT * fT * fT - fT) * m_pPoints[dwHBound].vPositionD2) * (dT * dT / 6.0f);

    // Interpolate orientation
    D3DXQuaternionSquad(&qOrientation, &m_pPoints[dwLBound].qOrientation,
        &m_pPoints[dwLBound].qOrientationD2, &m_pPoints[dwHBound].qOrientationD2,
            &m_pPoints[dwHBound].qOrientation, fT);
}

FLOAT CPath::GetPathTime()
{
    return m_fPathTime;
}

