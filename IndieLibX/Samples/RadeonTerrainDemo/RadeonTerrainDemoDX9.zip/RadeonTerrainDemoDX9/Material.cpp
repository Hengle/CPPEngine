

//-----------------------------------------------------------------------------
// File: Material.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "Material.h"
#include "DXErrors.h"

CMaterial::CMaterial()
{
    m_dwTexIndx = -1;
    ZeroMemory(&m_Mtrl, sizeof(D3DMATERIAL9));
}

CMaterial::~CMaterial()
{
    DeleteTexture();
}

HRESULT CMaterial::LoadMaterial(FILE *fp)
{
    HRESULT hr;
    BOOL mipmap, alpha, hasTexture;
    CHAR tname[32];
    CTexture *pTexture;

    fread(&m_Mtrl, sizeof(D3DMATERIAL9), 1, fp);
    fread(&hasTexture, sizeof(BOOL), 1, fp);
    fread(&mipmap, sizeof(BOOL), 1, fp);
    fread(&alpha, sizeof(BOOL), 1, fp);
    fread(tname, sizeof(CHAR), 32, fp);

    DeleteTexture();

    if (hasTexture)
    {
        pTexture = new CTexture();
        hr = pTexture->Create(tname, mipmap, alpha);
        if (FAILED(hr))
        {
            SAFE_DELETE(pTexture);
            return E_FAIL;
        }
        m_dwTexIndx = GameState::m_TMan->AddTexture(pTexture);
        if (m_dwTexIndx == -1)
        {
            SAFE_DELETE(pTexture);
            return E_FAIL;
        }
    }

    return S_OK;
}

HRESULT CMaterial::LoadMaterial(D3DMATERIAL9 &mtrl, TCHAR *tname, BOOL mipmap, BOOL alpha)
{
    HRESULT hr;
    CTexture *pTexture;

    m_Mtrl = mtrl;

    DeleteTexture();

    if (tname != NULL)
    {
        pTexture = new CTexture();
        hr = pTexture->Create(tname, mipmap, alpha);
        if (FAILED(hr))
        {
            SAFE_DELETE(pTexture);
            return E_FAIL;
        }
        m_dwTexIndx = GameState::m_TMan->AddTexture(pTexture);
        if (m_dwTexIndx == -1)
        {
            SAFE_DELETE(pTexture);
            return E_FAIL;
        }
    }

    return S_OK;
}

VOID CMaterial::SetMaterial()
{
//  HRESULT hr;

    GameState::m_pd3dDevice->SetMaterial(&m_Mtrl);
    if (m_dwTexIndx != -1)
    {
        CTexture *pTexture = GameState::m_TMan->GetTexture(m_dwTexIndx);
        if (pTexture != NULL)
            GameState::m_pd3dDevice->SetTexture(0, pTexture->GetSurface());
        else
            GameState::m_pd3dDevice->SetTexture(0, NULL);
    }
    else
        GameState::m_pd3dDevice->SetTexture(0, NULL);
}

VOID CMaterial::DeleteTexture()
{
    if (m_dwTexIndx != -1)
    {
        GameState::m_TMan->DeleteTexture(m_dwTexIndx);
        m_dwTexIndx = -1;
    }
}

