//-----------------------------------------------------------------------------
// File: Texture.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "Texture.h"
#include "DXErrors.h"

CTexture::CTexture()
{
    m_pddsSurface = NULL;
}

CTexture::~CTexture()
{
}

HRESULT CTexture::Create(TCHAR *strTexName, BOOL bMipMap, BOOL bAlpha)
{
    m_bMipMap = bMipMap;
    m_bHasAlpha = bAlpha;
    _stprintf(m_strFileName, _T("%s%s.bmp"), TEXTURE_PATH, strTexName);

    return S_OK;
}

HRESULT CTexture::Restore()
{
    HRESULT hr;
//  DWORD dwFlags;
    /*D3DX_SURFACEFORMAT sf;

    if (m_bMipMap)
        dwFlags = NULL;
    else
        dwFlags = D3DX_TEXTURE_NOMIPMAP;

    sf = D3DX_SF_A8R8G8B8;

    hr = D3DXCreateTextureFromFile(GameState::m_pd3dDevice,
        &dwFlags,
        0,
        0,
        &sf,
        NULL,
        &m_pddsSurface,
        NULL,
        m_strFileName,
        D3DX_FT_LINEAR);
*/
hr=D3DXCreateTextureFromFile( GameState::m_pd3dDevice, m_strFileName, &m_pddsSurface );

    if (FAILED(hr))
    {
        DD_ERR(hr);
        return E_FAIL;
    }

    return S_OK;
}

VOID CTexture::Invalidate()
{
    SAFE_RELEASE(m_pddsSurface);
}

LPDIRECT3DTEXTURE9 CTexture::GetSurface()
{
    return m_pddsSurface;
}
