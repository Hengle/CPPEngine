

//-----------------------------------------------------------------------------
// File: FlyDemo.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include "Helper.h"
#include "FlyDemo.h"
#include "Viewer.h"
#include "DXErrors.h"


CFlyDemo::CFlyDemo() : CDemo()
{
    m_pSky = new CSkyDome();
    m_pTerrain = new CTerrain();
    m_pPath = new CPath();

    m_bLoaded = FALSE;
    m_bInitialized = FALSE;
}

CFlyDemo::~CFlyDemo()
{
    SAFE_DELETE(m_pSky);
    SAFE_DELETE(m_pTerrain);
    SAFE_DELETE(m_pPath);
}

HRESULT CFlyDemo::Load()
{
    // Load geometry
    if (FAILED(m_pSky->Load()))
        return E_FAIL;
    if (FAILED(m_pTerrain->Load()))
        return E_FAIL;

    // Load fly path
    m_pPath->Load("path.dat");
    m_bLoaded = TRUE;

    return S_OK;
}

HRESULT CFlyDemo::Init()
{
    HRESULT hr;

    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
    GameState::m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);//D3DTSS_ADDRESS, D3DTADDRESS_WRAP);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);//D3DTSS_ADDRESS, D3DTADDRESS_WRAP);
    GameState::m_pd3dDevice->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP);//D3DTSS_ADDRESS, D3DTADDRESS_WRAP);

    //GameState::m_pd3dDevice->SetRenderState(D3DRS_TEXTUREPERSPECTIVE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_DITHERENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_COLORVERTEX, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_SHADEMODE, D3DSHADE_GOURAUD);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_ZENABLE, TRUE);
    GameState::m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);

    hr = m_pSky->Init();
    if (FAILED(hr))
    {
        DD_ERR(hr);
        return E_FAIL;
    }

    hr = m_pTerrain->Init();
    if (FAILED(hr))
    {
        DD_ERR(hr);
        return E_FAIL;
    }

    m_bInitialized = TRUE;

    return S_OK;
}

VOID CFlyDemo::Destroy()
{
    m_bInitialized = FALSE;
    m_pSky->Destroy();
    m_pTerrain->Destroy();
}

HRESULT CFlyDemo::Render(FLOAT fTime )
{
    if ((m_bLoaded) && (m_bInitialized))
    {
        D3DXVECTOR3 v, vpos;
        D3DXQUATERNION q;

        // Calculate position
        m_pPath->Play(fTime, vpos, q);

        if (m_bWireframe)
        {
            GameState::m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
            // Clear only when drawing wireframe to prevent overdraw
            //  use some weird color so wireframe stands out
            GameState::m_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
                0x00FF00FF, 1.0f, 0);
        }

        // For sky rendering place viewer in the center of skydome
        v = D3DXVECTOR3(0.0f, vpos.y * 0.2f, 0.0f);
        GameState::m_Viewer->UpdateViewer(v, q);
        // Render sky
        m_pSky->Render();

        GameState::m_Viewer->UpdateViewer(vpos, q);
        // Render terrain
        m_pTerrain->Render();

        if (m_bWireframe)
            GameState::m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
    }

    return S_OK;
}

DWORD CFlyDemo::CountPolys()
{
    return m_pSky->CountPolys() + m_pTerrain->CountPolys();
}

FLOAT CFlyDemo::GetFlightTime()
{
    return m_pPath->GetPathTime();
}

