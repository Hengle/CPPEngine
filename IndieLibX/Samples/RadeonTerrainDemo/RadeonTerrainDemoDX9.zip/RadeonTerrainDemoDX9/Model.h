

//-----------------------------------------------------------------------------
// File: Model.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _MODEL_H
#define _MODEL_H

#include "DXErrors.h"

class CModel
{
public:
    CModel() {};
    virtual HRESULT Load() { return S_OK; };
    virtual HRESULT Init() { return S_OK; };
    virtual VOID Destroy() {};
    virtual HRESULT Render() { return S_OK; };
    virtual DWORD CountPolys() { return 0; };
};

#endif

