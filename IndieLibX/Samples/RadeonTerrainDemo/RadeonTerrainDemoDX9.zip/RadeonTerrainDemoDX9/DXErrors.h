

//-----------------------------------------------------------------------------
// File: DXErrors.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _DDERRORS_H
#define _DDERRORS_H

#define STRICT
#define D3D_OVERLOADS
#define _CRT_SECURE_NO_WARNINGS
#include <tchar.h>
#include <stdio.h>

#include <windows.h>
#include <mmsystem.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <dxerr.h>
#include "LitVertex.h"

class CMaterialManager;
class CTextureManager;
class CViewer;
class CTerrainApp;
struct GameState
{
    static D3DCAPS9 m_caps;
    static LPDIRECT3D9 m_pD3D;
    static LPDIRECT3DDEVICE9 m_pd3dDevice;
    static CMaterialManager* m_MMan;
    static CTextureManager* m_TMan;
    static CViewer* m_Viewer;
    static CTerrainApp* m_App;
};

VOID _DbgOut(TCHAR* strFile, DWORD dwLine, HRESULT hr, TCHAR *strMsg);
VOID _ErrorOut(TCHAR *strFile, DWORD dwLine, HRESULT hr);

#if defined(DEBUG) | defined(_DEBUG)
    #define DD_ERR(hr) _ErrorOut(__FILE__, (DWORD)__LINE__, hr)
#else
    #define DD_ERR(hr)
#endif

#endif

