

//-----------------------------------------------------------------------------
// File: Skydome.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _SKYDOME_H
#define _SKYDOME_H

#include "DXErrors.h"
#include "Model.h"
#include "Material.h"
#include "LitVertex.h"

class CSkyDome : public CModel
{
    DWORD m_mSkyID;
    DWORD m_mGroundID;
    // Sky mesh
    LPLITVERTEX m_pSkyVert;
    DWORD m_dwSkyNumVert;
    LPDIRECT3DVERTEXBUFFER9 m_pSkyVB;
    // Ground mesh
    LPLITVERTEX m_pGroundVert;
    DWORD m_dwGroundNumVert;
    LPDIRECT3DVERTEXBUFFER9 m_pGroundVB;

public:
    CSkyDome();
    ~CSkyDome();
    HRESULT Load();
    HRESULT Init();
    VOID Destroy();
    HRESULT Render();
    DWORD CountPolys();
};

#endif

